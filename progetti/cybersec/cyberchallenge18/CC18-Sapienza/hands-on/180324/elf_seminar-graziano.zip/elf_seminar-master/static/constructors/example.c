#include <stdio.h>

void my_init(void) __attribute__ ((constructor));
void my_fini(void) __attribute__ ((destructor));

void my_init(void) 
{
    printf("Hello from the constructor\n");
}

void my_fini(void) 
{
    printf("Hello from the deconstructor\n");
}

int main(void) 
{
    printf("Hello from main\n");

return 0;
}
