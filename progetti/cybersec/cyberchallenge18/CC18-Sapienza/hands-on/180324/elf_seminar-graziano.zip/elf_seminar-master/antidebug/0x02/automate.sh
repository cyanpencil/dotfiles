gcc -g -o hello hello.c
echo ":: Normal run..."
./hello

echo -ne "\n\n"
echo ":: strace run..."
strace ./hello


echo -ne "\n\n"
echo ":: ltrace run..."
ltrace ./hello


echo -ne "\n\n"
echo ":: GDB run..."
echo "r" | gdb ./hello

rm hello
