gcc -g -o hello hello.c

echo ":: Normal run"
./hello

echo -ne "\n\n\n"
echo ":: GDB run"
echo -ne "r\nhandle SIGTRAP pass\nc\nquit\n" | gdb -q ./hello

rm hello

