#include <stdio.h>

int main(void)
{
    int a;
    int i;
    a = 10;
    int b = 4;
    int c = a+b;
    printf("Hello my cruel world!\n");
    int array[256];
    for(i = 0; i < 256; i++)
        array[i] = 0;

return 0;
}
