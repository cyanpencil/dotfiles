#include <stdio.h>
#include <unistd.h>
 
void detect_gdb(void) __attribute__((constructor));
 
void
detect_gdb(void)
{
        FILE *fd = fopen("/tmp", "r");
        if (fileno(fd) > 3)
        {
           printf("fuck you gdb!\n");
           _exit(1);
        }
        fclose(fd);
}
 
int
main(void)
{
        printf("do stuff outside gdb\n");
        return 0;
}

