#include <stdio.h>

void print_hello(void)
{
    printf("Print hello!\n");
}

void print_world(void)
{
    printf("Print world!\n");
}

int main(void)
{
    int a;

    a = 0;
    print_hello();
    print_world();

    return 0;
}

