#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

int debugger = 0;

static void _sigtrap_handler(int signum)
{
    printf("Oops... My secret world...\n");
}

int main(void)
{
    
    signal(SIGTRAP, _sigtrap_handler);  
    __asm__("int3");
    printf("Hello world!\n");


return 0;
}
