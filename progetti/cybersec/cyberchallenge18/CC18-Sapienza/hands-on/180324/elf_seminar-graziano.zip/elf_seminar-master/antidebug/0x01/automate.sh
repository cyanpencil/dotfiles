echo ":: Run no debugger..."
gcc -o hello hello.c
./hello

echo -ne "\n\n\n\n"
echo ":: Run with debugger..."
echo "r" | gdb -q hello

rm hello
