#include <stdio.h>

int main(void)
{
    printf("Hello my cruel world!\n");

return 0;
}
