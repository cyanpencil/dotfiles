#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int detect_gdb_env(char **envp)
{
    char *p = getenv("_");
    if(!strncmp("/usr/bin/gdb", p, 12))
        return 1;
return 0;
}

int main(int argc, char **argv, char **envp)
{
    int a = detect_gdb_env(envp);
    if (a == 1)
    {
        printf("Hello GDB\n");
    } else 
    {
        printf("Hello world\n");
    }
}
