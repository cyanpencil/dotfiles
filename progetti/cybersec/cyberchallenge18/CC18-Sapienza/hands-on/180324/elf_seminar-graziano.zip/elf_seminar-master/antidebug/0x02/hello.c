#include <stdio.h>
#include <sys/ptrace.h>
#include <stdlib.h>

int main(void)
{
    if(ptrace(PTRACE_TRACEME, 0, 0, 0) < 0)
    {
        printf("The horror the horror! I don't like debuggers....\n");
        exit(1);
    }
    printf("Hello world\n");

return 0;
}

