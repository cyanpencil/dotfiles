gcc -g -o hello hello.c
gcc -g -o hello1 hello1.c

echo ":: Normal run"
./hello

echo ":: GDB run"
echo "r" | gdb -q ./hello


echo -ne "\n\n"
echo ":: Normal run"
./hello1

echo ":: GDB run"
echo "r" | gdb -q ./hello1

rm hello
rm hello1

