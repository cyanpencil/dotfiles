echo ":: Attack..."
gcc -g -o killgdb killgdb.c
gcc -g -o hello hello.c
gcc -g -o patch00 patch.c
objcopy --only-keep-debug hello hello.debug
strip hello
objcopy --add-gnu-debuglink=hello.debug hello
./killgdb hello
gdb -q ./hello

echo -ne "\n\n\n"
echo "Patching..."
./patch00 hello

echo "disass main" | gdb -q hello
rm hello
rm hello.debug
rm killgdb
rm patch00
