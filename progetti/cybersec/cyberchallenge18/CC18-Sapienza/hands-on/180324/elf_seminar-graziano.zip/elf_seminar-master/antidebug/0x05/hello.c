#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int detect_gdb_env(char **envp){
    char **p;
    for (p = envp; *p != NULL; p++) 
    {
        int line = (strncmp("LINES", *p, 5));
        int column = (strncmp("COLUMNS", *p, 7));
        if ((line == 0) || (column == 0))
        {
            printf("lines = %d \t columns = %d\n", line, column);
            return 1;
        }
    }
return 0;
}

int main(int argc, char **argv, char **envp)
{
    int a = detect_gdb_env(envp);
    if (a == 1)
    {
        printf("Hello GDB\n");
    } else 
    {
        printf("Hello world\n");
    }
}
