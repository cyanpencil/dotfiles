
	execute the binary 
	=======================================================

	root@lcdtest:/home/hacker/fmt_vuln# ./fmt_vuln test
	Out:test

	Sorry, we can't identified you as 1337 member :( 
	[DEBUG] flag @ 0x0804a030 = 1


	--> find out the correct password




