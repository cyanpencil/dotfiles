#!/bin/bash


cd $(dirname $0)


python interface.py
