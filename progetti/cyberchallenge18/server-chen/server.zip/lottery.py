
class Lottery(db.Model):
    id = db.Column(db.Integer, primary_key=True)
